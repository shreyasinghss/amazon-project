package Amazon;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class amazonclass {

	public static void main(String[] args) throws IOException {
		
		
        WebDriver driver = new ChromeDriver();
		
		driver.get("https://www.amazon.in/");
		
		driver.manage().window().maximize();
		 
		   File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			

			File destFile = new File("./Screenshots/amazon.png");

			FileUtils.copyFile(srcFile, destFile);
		 driver.findElement(By.id("nav-link-accountList-nav-line-1")).click();
		
		 driver.findElement(By.id("ap_email")).sendKeys("shrryasingh1503@gmail.com");   //Please enter a valid email or phone no.
		 
		 driver.findElement(By.id("continue")).click();
		 
		 driver.findElement(By.id("ap_password")).sendKeys("Bahubali@1503"); //Please enter a valid password
		 
		 driver.findElement(By.id("signInSubmit")).click();
		 
		   File srcFile3 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			

			File destFile4 = new File("./Screenshots/amazon.png");

			FileUtils.copyFile(srcFile, destFile);
			
		 WebElement e1 =  driver.findElement(By.id("searchDropdownBox"));
		  e1.click();
		  Select dd = new Select(e1);
		  dd.selectByVisibleText("Amazon Devices");
		  
		  driver.findElement(By.id("twotabsearchtextbox")).sendKeys("iphone 13");
		   WebElement e2 = driver.findElement(By.id("nav-search-submit-button"));
		   e2.click();
		   
		   File srcFile2 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			

			File destFile2 = new File("./Screenshots/amazon.png");

			FileUtils.copyFile(srcFile, destFile);
		   driver.findElement(By.xpath("//*[@id=\"search\"]/div[1]/div[1]/div/span[1]/div[1]/div[4]/div/div/div/div/div/div[2]/div/div/div[1]/h2/a/span")).click();
	
		   driver.findElement(By.id("add-to-wishlist-button-submit")).click();
		   
		   
		   File srcFile1 = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

			

			File destFile1 = new File("./Screenshots/amazon.png");

			FileUtils.copyFile(srcFile, destFile);
		   
		    }
		


	}


